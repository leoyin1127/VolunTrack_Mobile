const colors = {
    background: '#F9F9FB', //white
    textDark: '#313234', //black
    primary: '#3069F3', //blue
    secondary: '#748c94', //dark gray
    textLight: '#D9D9D9', //light gray
    highlight: 'FFE600', //yellow
} 

export default colors;