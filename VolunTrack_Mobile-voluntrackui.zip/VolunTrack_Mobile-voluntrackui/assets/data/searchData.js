const searchData = [
    {
        id: 'search-1',
        title: 'Brockville Summer Camp', 
        location: 'Markham',
        duration: 20,
        bookmark: true, 
        image: require('../images/susan-g-komen-3-day-qfWMUXDcN18-unsplash.jpg')
    }, 
    {
        id: 'search-2',
        title: 'Camp Muskoka',
        location: 'North York', 
        duration: 20, 
        bookmark: false,
        image: require('../images/jacek-dylag-PMxT0XtQ--A-unsplash.jpg')

    }
]

export default searchData;